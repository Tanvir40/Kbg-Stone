

<?php $__env->startSection('content'); ?>
<div class="inner-page-bg-white">
    <div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"> 
    <h1 class="inner-page-title-heading">Marble Slabs Manufacturers</h1> 
    <div style="text-align: center">Unit 6, 1003-1009 Canley Vale Road Wetherill Park,</br> NSW, Australia 2164</div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
    <div class="inner-page-text">
    <p>  <strong><a href="index.html">FINEST MARBLE Collection</a></strong> from all over Australia, you can choose from more blends, colors, & styles below….today we are counted amongst the Best Marble Slabs Manufacturer in Austrlia. KBG Stone, one of the top  Marble Companies in Austrlia offers high quality marble slabs for your bathroom vanities, walls, showers and more. If you are looking for more colors you can find them in our inventory below…</p>
    
    <p>Our company is a premier Manufacturer, Retailer and Wholesaler of Marble Slabs, Marble Tiles and Marble Blocks of various colors like the fastest moving. KBG Stone offer various  Marbles in various sizes and finishes in the form of slabs & steps risers etc.</p> 
    </div>
    </div>
    
    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6"><img src="<?php echo e(asset('frontend/images/303142152_10224400654776543_6550171894049598402_n.jpg')); ?>" alt="Marble Slabs Manufacturers" title="Marble Slabs Manufacturers" class="img-responsive center-block"></div>
    
    
    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
    <div class="inner-page-text">
    <ul>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(url('/new-Stones/'.$category->id)); ?>"><?php echo e($category->category_name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>
    
    </div>
    </div>
    
    </div>
    </div>
    
    <div class="qpsd-zone">
    <div class="container-fluid">
    <div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"><div class="footer-heading"><span>Be 100% Assured for Best Quality, Price, Service &amp; Delivery</span></div></div>
    </div>
    </div>
    </div>
    
    <div class="container certificates">
    <div class="row">
    
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\my work space\My Web Design and Development Work\web development\Laravel\kbgstoneau\front end design\laravel\resources\views/frontend/marbel.blade.php ENDPATH**/ ?>