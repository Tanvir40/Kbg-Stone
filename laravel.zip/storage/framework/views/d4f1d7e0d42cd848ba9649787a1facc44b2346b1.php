

<?php $__env->startSection('content'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->

    <!-- /.content-header -->

    <!-- Main content -->
    <div class="container-xl">
        <div class="table-responsive">
            <div class="table-wrapper">
                <div class="table-title">
                    <div class="row">


                    </div>
                </div>


                <div class="col-md-6 m-auto">
                    <h3>Update 2nd Banner</h3>
                    <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Image Update</h3>
                    </div>
                    <div class="col-12">
                                <?php if($message = Session::get('success')): ?>
                                    <div class="alert alert-success contact__msg"  role="alert">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php endif; ?>
                                </div>
                    <form action="<?php echo e(route('save.2nd.banner')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <input type="hidden" name="id" class="form-control" value="<?php echo e($banners2->first()->id); ?>">
                        <div class="form-group mt-2">
                            <div class="input-group">
                                <div class="custom-file">
                                        <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                        <input type="file" name="bannerimage" class="form-control" >
                                        <img class="mt-2" width="100px" src="<?php echo e(asset('frontend/images/2nd')); ?>/<?php echo e($banners2->first()->bannerimage); ?>" alt="">
                                    <?php $__errorArgs = ['bannerimage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <strong class="text-danger"><?php echo e($message); ?></strong>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="form-group mt-2">
                            <label for="exampleInputEmail1">Banner Name</label>
                            <textarea name="bannername" class="form-control" id="exampleInputEmail1" cols="30" rows="10"><?php echo e($banners2->first()->bannername); ?></textarea>
                            <?php $__errorArgs = ['bannername'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                        <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                    </div>

                </div>

            </div>
        </div>
    </div>
  </div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\my work space\My Web Design and Development Work\web development\Laravel\kbgstoneau\front end design\laravel\resources\views/backend/banner_image_2.blade.php ENDPATH**/ ?>