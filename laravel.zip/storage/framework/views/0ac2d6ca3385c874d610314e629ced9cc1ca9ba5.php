

<?php $__env->startSection('content'); ?>
    

<div class="row full-width">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h2 class="m-auto">Marbel List</h2>
                 <a href="<?php echo e(route('add.marbel')); ?>" class="btn btn-danger float-end btn-sm"><i class="mdi mdi-plus-circle "></i> Add Marbel</a>
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><strong><?php echo e(session('success')); ?></strong></div>
                <?php endif; ?>
            </div>
            <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <td>SL</td>
                    <td>Marbel Image</td>
                    <td>Marbel Name</td>
                    <th>Marbel Category</th>
                    <td>Marbel Room Category</td>
                    <th>Added Date</th>
                    <td>Action</td>
                </tr>
            </thead>
            <tbody>
                    <?php $__currentLoopData = $all_marbels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$marbel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td data-title="SL"><?php echo e($all_marbels->firstitem()+$key); ?></td>
                        <td data-title="Product Image">
                            <img src="<?php echo e(asset('frontend/images/marble/pictures')); ?>/<?php echo e($marbel->marbel_photo); ?>" alt="contact-img" title="contact-img" class="rounded me-3" height="48">
                        </td>
                        <td data-title="Product Name"><?php echo e($marbel->marbel_name); ?></td>
                        <td data-title="Category"><?php echo e($marbel->rel_to_cat->category_name); ?></td>
                        <td data-title="Category"><?php echo e($marbel->rel_to_catroom->categoryroom_name); ?></td>
                        <td data-title="Product Name"><?php echo e($marbel->created_at->format('d-m-Y H-i A')); ?></td>
                        <td class="table-action" data-title="Action">
                            <button type="button" name="<?php echo e(route('marbel.delete' , $marbel->id)); ?>" class="action-icon delete"> <i class="mdi mdi-delete"></i></button> 
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($all_marbels->links()); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_script'); ?>
 
 <script>
    $('.delete').click(function(){
        Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
        if (result.isConfirmed) {
           var link = $(this).attr('name');
           window.location.href =link;
        }
        })
    })
</script>
<?php if(session('delete')): ?>
<script>
    Swal.fire(
      'Deleted!',
      '<?php echo e(session('delete')); ?>',
      'success'
    )
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\my work space\My Web Design and Development Work\web development\Laravel\kbgstoneau\front end design\laravel\resources\views/backend/marbel_list.blade.php ENDPATH**/ ?>