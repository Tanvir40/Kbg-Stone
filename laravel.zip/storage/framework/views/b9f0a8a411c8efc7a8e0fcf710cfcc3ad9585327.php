

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row mt-3">

        <div class="col-lg-9">
            <div class="card">
            <div class="card-header">
                <h2>Marbel Category List</h2>
            </div>

            <div class="card-body">
                
                <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>SL</th>
                            <th>Added By</th>
                            <th>Marbel Category Name</th>
                            <th>Created At</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-title="SL"><?php echo e($categories->firstitem()+$key); ?></td>
                            <td data-title="Added By">
                            <?php
                            if(App\Models\User::where('id', $category->user_id)->exists()){
                                echo $category->rel_to_user->name;
                            }
                            else{
                                echo 'N/A';
                            }
                            ?>
                            </td>
                            <td data-title="Category Name"><?php echo e($category->category_name); ?></td>
                            <td data-title="Created At"><?php echo e($category->created_at->format('d-m-Y H-i A')); ?></td>
                            <td data-title="Action">
                                <button type="button" name="<?php echo e(route('category.add.delete' , $category->id)); ?>" class="delete btn btn-danger shadow btn-xs sharp mr-1"><i class="fa fa-trash"></i></button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($categories->links()); ?>

            </div>
            </div>
            </div>
        </div>

        <div class="col-lg-3">
            <div class="card">
            <div class="card-header">
                <h2>Add Category</h2>
            </div>
            <div class="card-body">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><strong><?php echo e(session('success')); ?></strong></div>
                <?php endif; ?>
                <form action="<?php echo e(route('save.marbel.cat')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label class="form-label">Marbel Category Name</label>
                        <input type="text" class="form-control" name="category_name">
                        <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong class="text-danger"><?php echo e($message); ?></strong>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <br>
                    <button type="submit" class="btn btn-info">Add new</button>
                </form>
            </div>
            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_script'); ?>
 
 <script>
    $('.delete').click(function(){
        Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
        if (result.isConfirmed) {
           var link = $(this).attr('name');
           window.location.href =link;
        }
        })
    })
</script>
<?php if(session('delete')): ?>
<script>
    Swal.fire(
      'Deleted!',
      '<?php echo e(session('delete')); ?>',
      'success'
    )
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\my work space\My Web Design and Development Work\web development\Laravel\kbgstoneau\front end design\laravel\resources\views/backend/add_marbel_cat.blade.php ENDPATH**/ ?>