

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h3 class="text-center">Customer Form Submit</h3>
                <div id="no-more-tables">
                    <table class="table table-striped ">
                        <thead>
                            <tr>
                                <td>SL</td>
                                <td>Name</td>
                                <td>Marbel Name</td>
                                <td>Email</td>
                                <th>Phone</th>
                                <th>Requirement</th>
                                <th>Submited At</th>
                                <td>Action</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td data-title="SL"><?php echo e($contacts->firstitem()+$key); ?></td>
                                <td data-title="Name"><?php echo e($contact->name); ?></td>
                                <td data-title="Name"><?php echo e($contact->marbel_name); ?></td>
                                <td data-title="Email"><?php echo e($contact->email); ?></td>
                                <td data-title="Phone"><?php echo e($contact->phone); ?></td>
                                <td data-title="Requirement"><?php echo e($contact->requirement); ?></td>
                                <td data-title="Submited At"><?php echo e($contact->created_at->format('d-m-Y H-i A')); ?></td>
                                <td data-title="Action">
                                    <button type="button" name="<?php echo e(route('contact.delete' , $contact->id)); ?>" class="delete btn btn-danger shadow btn-xs sharp mr-1"><i class="fa fa-trash"></i></button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <?php echo e($contacts->links()); ?>


                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_script'); ?>
 
 <script>
    $('.delete').click(function(){
        Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
        if (result.isConfirmed) {
           var link = $(this).attr('name');
           window.location.href =link;
        }
        })
    })
</script>
<?php if(session('delete')): ?>
<script>
    Swal.fire(
      'Deleted!',
      '<?php echo e(session('delete')); ?>',
      'success'
    )
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\my work space\My Web Design and Development Work\web development\Laravel\kbgstoneau\front end design\laravel\resources\views/backend/view_contact.blade.php ENDPATH**/ ?>